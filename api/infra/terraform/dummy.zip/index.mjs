export const handler = async (event) => {
	// TODO implement
	const response = {
		statusCode: 200,
		body: JSON.stringify("I'm a dummy"),
	};
	return response;
};
